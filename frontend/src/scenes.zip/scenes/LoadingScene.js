import Phaser from 'phaser';

export default class LoadingScene extends Phaser.Scene {
  constructor() {
    super({ key: 'LoadingScene' });
    this.waitingForFocus = false;
  }

  init(data) {
    this.nextSceneData = data;
  }

  preload() {
    const { width, height } = this.scale;
    this.add.rectangle(width / 2, height / 2, width, height, 0x222222, 0.95);

  const isSmall = width < 500;
  const loadingFontSize = isSmall ? '16px' : '28px';
  const barWidth = isSmall ? Math.min(220, width * 0.85) : Math.min(400, width * 0.7);
  const barHeight = isSmall ? 16 : 28;

  this.add.rectangle(width / 2, height / 2, width, height, 0x222222, 0.95);

  const loadingText = this.add.text(width / 2, height / 2 - (isSmall ? 32 : 60), 'Cargando sprites y recursos...', {
    fontSize: loadingFontSize,
    color: '#fff',
    fontFamily: 'Arial Black, Arial, sans-serif'
  }).setOrigin(0.5);

  const barBg = this.add.rectangle(width / 2, height / 2, barWidth, barHeight, 0x444444).setOrigin(0.5);
  const bar = this.add.rectangle(width / 2 - barWidth / 2, height / 2, 0, barHeight, 0xD2F562).setOrigin(0, 0.5);

  this.load.on('progress', (value) => {
    bar.width = barWidth * value;
  });
    // Si la pestaña NO está activa, espera
    if (document.hidden) {
      loadingText.setText('Activa esta pestaña para continuar la carga...');
      this.waitingForFocus = true;
      const onFocus = () => {
        if (!document.hidden) {
          this.waitingForFocus = false;
          document.removeEventListener('visibilitychange', onFocus);
          this.scene.restart(this.nextSceneData); // reinicia la escena y carga assets
        }
      };
      document.addEventListener('visibilitychange', onFocus);
      return;
    }

  
    // Carga todos los assets necesarios para PlayScene
    this.load.multiatlas('cards', '/assests/Cartas/cartas.json', '/assests/Cartas/');
    this.load.multiatlas('cambiacolor', '/assests/cambiacolor/cambiacolor.json', '/assests/cambiacolor/');
    this.load.multiatlas('mas4', '/assests/mas4/mas4.json', '/assests/mas4/');
    this.load.image('fondoMobile', '/assests/img/framegreen.png');
    this.load.image('fondoDesktop', '/assests/img/Background2.png');
    this.load.image('mesa', '/assests/img/Ring_Solo.png');
    this.load.image('Persona', '/assests/img/Persona.png');
    this.load.image('Persona2', '/assests/img/Persona2.png');
    this.load.image('PersonaChica', '/assests/img/PersonaChica.png');
    this.load.image('PersonaChica2', '/assests/img/PersonaChica2.png');
    this.load.image('avatar-def', '/assests/img/avatar-default.png');

    if (this.nextSceneData && this.nextSceneData.players) {
      this.nextSceneData.players.forEach(p => {
        if (p.avatar) {
          this.load.image('avatar-' + p.playerId, p.avatar, { crossOrigin: 'anonymous' });
        }
      });
    }

    this.load.on('complete', () => {
      this.scene.start('PlayScene', this.nextSceneData);
    });
  }
  create() {
  window._phaserActiveScene = this.scene.key;
window.dispatchEvent(new Event('phaser-scene-changed'));}

}